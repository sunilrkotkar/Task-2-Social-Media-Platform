const express = require('express'); const dotenv = require('dotenv'); const cors = require('cors'); const bodyParser = require('body-parser');
const connectDB = require('./config/db'); const userRoutes = require('./routes/userRoutes'); const postRoutes = require('./routes/postRoutes');
dotenv.config(); connectDB(); const app = express(); app.use(cors()); app.use(bodyParser.json()); app.use('/api/users', userRoutes); app.use('/api/posts', postRoutes);
app.listen(process.env.PORT, () => console.log(`Server running on port ${process.env.PORT}`));