const express = require('express'); const User = require('../models/User'); const router = express.Router();
router.post('/register', async (req, res) => { const { username } = req.body; const user = new User({ username }); await user.save(); res.json(user); });
router.post('/follow', async (req, res) => { const { userId, followId } = req.body; await User.findByIdAndUpdate(userId, { $addToSet: { followers: followId } }); res.json({ message: 'Followed' }); });
module.exports = router;