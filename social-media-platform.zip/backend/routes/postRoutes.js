const express = require('express'); const Post = require('../models/Post'); const router = express.Router();
router.post('/create', async (req, res) => { const { user, content } = req.body; const post = new Post({ user, content }); await post.save(); res.json(post); });
router.post('/like', async (req, res) => { const { postId, userId } = req.body; await Post.findByIdAndUpdate(postId, { $addToSet: { likes: userId } }); res.json({ message: 'Liked' }); });
router.post('/comment', async (req, res) => { const { postId, userId, text } = req.body; await Post.findByIdAndUpdate(postId, { $push: { comments: { user: userId, text } } }); res.json({ message: 'Comment Added' }); });
module.exports = router;